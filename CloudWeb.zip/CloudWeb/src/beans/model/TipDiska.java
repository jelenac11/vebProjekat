package beans.model;

public enum TipDiska {
	HDD, SSD
}

package beans.model;

public enum Uloga {
	SUPER_ADMIN, ADMIN, KORISNIK
}
